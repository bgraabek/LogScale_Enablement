
# README
LogScale package for EMEA SE enablement 2023

bjorn.graabek@crowdstrike.com